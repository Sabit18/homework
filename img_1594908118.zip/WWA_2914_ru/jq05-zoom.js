			$(document).ready(function(){
				let images = Array.from($("img")).map(item=>item.src);
				let img = "";
				let x;
				
				$("body").append('<div id="zoom"><div><button id="zoomX">&#10799;</button><button id="zoomP">&#11207;</button><button id="zoomN">&#11208;</button></div></div>');
				$("#zoom").css({
					display: "none",
					position: "fixed",
					zIndex: "99",
					top: "0",
					left: "0",
					width: "100%",
					height: "100vh",
					background: "rgba(0,0,0,.7)"
				});
				$("#zoom>div").css({
					margin: "auto",
					width: "800px",
					height: "600px",
					border: "20px solid #fff",
					background: "#EFEFEF center/cover",
					position: "relative"
				});
				$("#zoom button").css({
					border: "none",
					outline: "none",
					borderRadius: "50%",
					background: "#FFF",
					boxShadow: "0 0 5px gray",
					font: "1em/1em Arial",
					position: "absolute",
					cursor: "pointer"
				});
				$("#zoomX").css({
					top: "-20px",
					right: "-20px"
				});
				$("#zoomP").css({
					display: "none",
					top: "300px",
					left: "0"
				});
				$("#zoomN").css({
					display: "none",
					top: "300px",
					right: "0"
				});
				
				$("img").click(function(){
					x = images.indexOf($(this)[0].src);
					img = $(this).attr("src");
					open();
				});
				
				$("#zoom").click(close);
				$("#zoomX").click(close);
				$("#zoomP").click(function(){
					x--;
					img = images[x];
					open();
				});
				$("#zoomN").click(function(){
					x++;
					img = images[x];
					open();
				});
				
				$("#zoom>div").on({
					mousemove: function(e){
						if(e.pageX < $(document).width() / 2 - 200 && x > 0) {
							$("#zoomP").fadeIn('500');
						} else if(e.pageX > $(document).width() / 2 + 200 && x < images.length - 1) {
							$("#zoomN").fadeIn('500');
						} else {
							$("#zoomP").fadeOut('500');
							$("#zoomN").fadeOut('500');
						}			
					},
					mouseleave: function(){
						$("#zoomP").fadeOut('500');
						$("#zoomN").fadeOut('500');
					},
					click: function(e) {
						e.stopPropagation();
					}
				})
				
				function open() {
					$("#zoom>div").css("backgroundImage", "url('" + img + "')");
					$("#zoom").fadeIn("slow").css("display", "flex");
				}
				
				function close(){
					$("#zoom").fadeOut("slow");
				}
			});