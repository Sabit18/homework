import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutfull',
  templateUrl: './aboutfull.component.html',
  styleUrls: ['./aboutfull.component.css']
})
export class AboutfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
